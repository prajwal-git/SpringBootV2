"use strict";
exports.__esModule = true;
var ProjectClass = /** @class */ (function () {
    // private pid : number;
    // private pname : string;
    function ProjectClass(_pid, _pname) {
        this._pid = _pid;
        this._pname = _pname;
        this._pid = _pid;
        this._pname = _pname;
    }
    ProjectClass.prototype.getCustomerReference = function () {
        // ......
        console.log('ID : ' + this._pid + '  NAME:' + this._pname);
    };
    Object.defineProperty(ProjectClass.prototype, "pid", {
        get: function () {
            return this.pid;
        },
        set: function (value) {
            this.pid = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ProjectClass.prototype, "pname", {
        get: function () {
            return this.pid;
        },
        set: function (value) {
            this.pid = value;
        },
        enumerable: true,
        configurable: true
    });
    return ProjectClass;
}());
exports.ProjectClass = ProjectClass;
//let projectReference = new ProjectClass (1); // public ProjectClass projectReference =  new ;
//let id = projectReference.getPid;
//let id_way2 = projectReference.pid;
//projectReference.getCustomerReference();
// Access Modifier 
// public -- default  
// private 
// protected 
