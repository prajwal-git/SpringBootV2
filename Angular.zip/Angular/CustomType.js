//Inline Notation
var getCustomerReference = function (CustomerReference) {
    // code 
};
getCustomerReference({
    pid: 1,
    pname: 'Prajwal'
});
