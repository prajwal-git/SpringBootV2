export class ProjectClass {
   // private pid : number;
   // private pname : string;

    constructor(private _pid ? : number,private _pname ?: string) { // ProjectClass()
        this._pid = _pid ;
        this._pname = _pname; 
    }
        
    getCustomerReference(){
        // ......
        console.log ('ID : '+ this._pid +'  NAME:' + this._pname);
        }

    get pid(){                                // public int getPid(){ return this.pid;}
        return this.pid;
    }   
    
    set pid(value){
     this.pid = value;
    }

    get pname(){                                // public int getPid(){ return this.pid;}
    return this.pid;
    }   
    set pname(value){
    this.pid = value;
    }
}


//let projectReference = new ProjectClass (1); // public ProjectClass projectReference =  new ;

//let id = projectReference.getPid;

//let id_way2 = projectReference.pid;


//projectReference.getCustomerReference();

// Access Modifier 
// public -- default  
// private 
// protected 