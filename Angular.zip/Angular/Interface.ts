interface Project {

    pid : number;
    pname : string;

    getCustomerReference:() => void;
    assignProject : () => string;
}

