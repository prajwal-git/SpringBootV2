import {ProjectClass} from './Class'; 

let projectReference = new ProjectClass (1);

projectReference.getCustomerReference;