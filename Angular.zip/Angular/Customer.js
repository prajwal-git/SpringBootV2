"use strict";
exports.__esModule = true;
var Class_1 = require("./Class");
var projectReference = new Class_1.ProjectClass(1);
projectReference.getCustomerReference;
