
    
 

    //Inline Notation

    let getCustomerReference = (CustomerReference :{
        pid : number ,
        pname: string
    }) => {

     // code 
    }

    getCustomerReference({
        pid : 1 ,
        pname: 'Prajwal'
        });
        
        