package com.zorba.Hibernate2;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		System.out.println("Hello World!");

		Customer cust = new Customer();

		cust.setId(1);
		cust.setName("Prajwal");

		// Configuration
		Configuration con = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Customer.class);

		// Factory Design Pattern
		SessionFactory sf = con.buildSessionFactory();

		// Get session
		Session session = sf.openSession();
		
		Transaction tx = session.beginTransaction();

		session.save(cust);
		tx.commit();
		
		System.out.println("Customer Saved");
	}
}
