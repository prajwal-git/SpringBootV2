package com.zorba;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Organization {

	@Id
	private int oId;
	private String oName ;
	public int getoId() {
		return oId;
	}
	public void setoId(int oId) {
		this.oId = oId;
	}
	public String getoName() {
		return oName;
	}
	public void setoName(String oName) {
		this.oName = oName;
	}
	@Override
	public String toString() {
		return "Organization [oId=" + oId + ", oName=" + oName + "]";
	}
	
}
