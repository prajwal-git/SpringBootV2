package com.zorba;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class HomeController {

	@RequestMapping("home")
	public ModelAndView home(Customer customer) {
		
		
        // getting thing from client
		System.out.println("My name :" +customer.getName());
		System.out.println("My id :" +customer.getId());
		
		// sending data to client 
		ModelAndView mv = new ModelAndView();
        mv.setViewName("home");
        mv.addObject("name",customer.getName());
        mv.addObject("id",customer.getId());
        mv.addObject("message","Customer fetched");
		
		return mv;
	}
	
	
	@GetMapping
	public ModelAndView getCustomers() {
		
		EntityManagerFactory emf =  Persistence.createEntityManagerFactory("ET");
		EntityManager em =  emf.createEntityManager();
        Customer customer = em.find(Customer.class, 101);
		
		// sending data to client 
		ModelAndView mv = new ModelAndView();
        mv.setViewName("home");
        mv.addObject("name",customer.getName());
        mv.addObject("id",customer.getId());
        mv.addObject("message","Customer fetched");
		
		return mv;
	}
	
}


//@RequestMapping("home")
//public String home(String name, int id,HttpSession session) {
//	
//	
//    // getting thing from client
//	System.out.println("My name :" +name);
//	System.out.println("My id :" +id);
//	
//	// sending to client
//	
//	session.setAttribute("name", name);
//	session.setAttribute("id", id);
//	session.setAttribute("message", "Customer fetched successfully");
//	
//	
//	return "home";
//}
//
//
//
//@RequestMapping("home")
//public String home(HttpServletRequest req) {
//	
//	
//    // getting thing from client
//	String name = req.getParameter("name");
//	String id = req.getParameter("id");
//	System.out.println("My name :" +name);
//	System.out.println("My id :" +id);
//	
//	// sending to client
//	HttpSession session = req.getSession();
//	session.setAttribute("name", name);
//	session.setAttribute("id", id);
//	session.setAttribute("message", "Customer fetched successfully");
//	
//	
//	return "home";
//}
//
//
//@RequestMapping("home")
//public String home(@RequestParam("cname") String name, @RequestParam("cid") int id,HttpSession session) {
//	
//	
//    // getting thing from client
//	System.out.println("My name :" +name);
//	System.out.println("My id :" +id);
//	
//	// sending to client
//	session.setAttribute("name", name);
//	session.setAttribute("id", id);
//	session.setAttribute("message", "Customer fetched successfully");
//	
//	
//	return "home";
//}