package com.zorba.Hibernate2;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Project {

	@Id
	private int pid;
	private String pName;
	

	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	

	@Override
	public String toString() {
		return "Project [pid=" + pid + ", pName=" + pName + "]";
	}
	
	
	
}
