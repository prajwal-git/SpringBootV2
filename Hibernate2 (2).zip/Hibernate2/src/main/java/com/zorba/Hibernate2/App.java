package com.zorba.Hibernate2;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		System.out.println("Hello World!");

	
		// Configuration
		Configuration con = new Configuration().configure("hibernate.cfg.xml")
				            .addAnnotatedClass(Customer.class);
				  
		// Factory Design Pattern
		SessionFactory sf = con.buildSessionFactory();
		// Get session
		
		Session session1 = sf.openSession();
		Transaction tx1 = session1.beginTransaction();
		
		Customer cust1 =  session1.get(Customer.class, 101);
		System.out.println("Get method :" + cust1);
		
		tx1.commit();
		session1.close();
		
		// Load session
		Session session2 = sf.openSession();
		Transaction tx2 = session2.beginTransaction();
		
		Customer cust2=  session2.load(Customer.class, 101);
		System.out.println("Before using Cust object --> Load method :" );
		cust2.getName();
		System.out.println("After using Cust object --> Load method :" );
		
		tx2.commit();
		
		session2.close();
	}
}

