package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Customer {

	private int id;
	private String name;
	
	@Autowired
	@Qualifier("p2")
	private Product product;
	
	
	public Customer() {
		super();
		System.out.println("Inside Customer Creation");
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}


	public void show() {
		System.out.println("Customer showing his properties ");
		product.inject();
	}
	
	
}
