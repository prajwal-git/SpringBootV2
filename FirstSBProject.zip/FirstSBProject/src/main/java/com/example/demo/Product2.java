package com.example.demo;

import org.springframework.stereotype.Component;

@Component("p2")
public class Product2 extends Product{

	@Override
	public void inject() {
		System.out.println("Product P2 got injected successfully");
	}
	
}
