package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class Product {

	private int id;
	private String pName;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	
	@Override
	public String toString() {
		return "Product [id=" + id + ", pName=" + pName + "]";
	}
	
	public void inject() {
		System.out.println("Product p got injected successfully");
	}
	
	
}
