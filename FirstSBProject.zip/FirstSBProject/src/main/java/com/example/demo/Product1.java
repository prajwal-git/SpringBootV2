package com.example.demo;

import org.springframework.stereotype.Component;

@Component("p1")
public class Product1 extends Product{

	private int id;
	private String p1Name;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getP1Name() {
		return p1Name;
	}
	public void setP1Name(String p1Name) {
		this.p1Name = p1Name;
	}
	
	@Override
	public String toString() {
		return "Product1 [id=" + id + ", p1Name=" + p1Name + "]";
	}
	
	@Override
	public void inject() {
		System.out.println("Product P1 got injected successfully");
	}
	
	
}
